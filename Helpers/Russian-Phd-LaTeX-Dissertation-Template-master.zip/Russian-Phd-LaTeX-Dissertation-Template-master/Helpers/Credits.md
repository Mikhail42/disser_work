##При создании шаблона использовались:
* Заготовка шаблона, разработанная [Юлией Мартыновой](http://alessia-lano.livejournal.com/4267.html)
* utf8gost705u.bst 0.1 beta, разработанный [Дмитрием Морозовым и Александром Вовненко](http://www.tex.uniyar.ac.ru/package/style/gost705.7z)